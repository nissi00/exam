package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import service.DepartementService;
import univ.fac.model.Departement;

@RestController
@RequestMapping("/departements")
public class DepartementController {
    @Autowired
    private DepartementService departementService;

    @GetMapping
    public List<Departement> getAllDepartements() {
        return departementService.getAllDepartements1();
    }

    @SuppressWarnings("rawtypes")
	@GetMapping("/{id}")
    public ResponseEntity<Departement> getDepartementById(@PathVariable Long id) {
        return ((DepartementService) departementService).getDepartementById(id)
                .map(departement -> ResponseEntity.ok().body(departement))
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Departement> ajouterDepartement(@RequestBody Departement<?> departement) {
        Departement nouveauDepartement = DepartementService.ajouterDepartement(departement);
        return ResponseEntity.status(HttpStatus.CREATED).body(nouveauDepartement);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> supprimerDepartement(@PathVariable Long id) {
        departementService.supprimerDepartement(id);
        return ResponseEntity.noContent().build();
    }
}
