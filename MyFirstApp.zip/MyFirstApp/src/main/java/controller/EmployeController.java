package controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import service.EmployeService;
import univ.fac.model.Employe;

@RestController
@RequestMapping("/departement")
public class EmployeController {
    @Autowired
    private EmployeService employeService1;

    @GetMapping("/{id}/employes")
    public List<Employe> getEmployesByDepartement(@PathVariable Long id) {
        return employeService1.getEmployesByDepartement(id);
    }
    
    @Autowired
    private EmployeService employeService;

    @PostMapping
    public ResponseEntity<Employe> ajouterEmploye(
            @RequestPart("employe") Employe employe,
            @RequestPart("photo") MultipartFile photo) {

        try {
            Employe savedEmploye = employeService1.ajouterEmploye(employe, photo);
            return ResponseEntity.ok(savedEmploye);
        } catch (IOException e) {
            return ResponseEntity.internalServerError().build();
        }
    }

}
