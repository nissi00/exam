package univ.fac.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Employe {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String nom;
    private String prenom;
    private int age;
    
    private String photoPath; // Stocke le chemin du fichier

    @ManyToOne
    @JoinColumn(name = "departement_id")
    private Departement departement;

	public void setPhotoPath(String filePath) {
		// TODO Auto-generated method stub
		
	}

	}

