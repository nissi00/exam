package univ.fac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyFirstApp {

	public static void main(String[] args) {
		SpringApplication.run(MyFirstApp.class, args);
	}

}
