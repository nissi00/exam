package repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import univ.fac.model.Employe;

@Repository
public interface EmployeRepository extends JpaRepository<Employe, Long> {
    List<Employe> findByDepartementId(Long departementId);
}
