package repository;

public interface JpaRepository<T1, T2> {

}
