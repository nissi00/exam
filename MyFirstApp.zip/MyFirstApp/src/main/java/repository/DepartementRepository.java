package repository;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

@Repository
public interface DepartementRepository<Departement> extends JpaRepository<Departement, Long> {

	Optional<univ.fac.model.Departement> findById(Long id);

	@SuppressWarnings("rawtypes")
	static univ.fac.model.Departement save(univ.fac.model.Departement departement) {
		// TODO Auto-generated method stub
		return null;
	}

	void deleteById(Long id);

	@SuppressWarnings("rawtypes")
	List<univ.fac.model.Departement> findAll();
}
