package service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import repository.DepartementRepository;
import univ.fac.model.Departement;

@Service
public class DepartementService {
    @Autowired
    private DepartementRepository departementRepository;

    public List<Departement> getAllDepartements() {
        return departementRepository.findAll();
    }

    public Optional<Departement> getDepartementById(Long id) {
        return departementRepository.findById(id);
    }

    public static Departement ajouterDepartement(Departement departement) {
        return DepartementRepository.save(departement);
    }

    public void supprimerDepartement(Long id) {
        departementRepository.deleteById(id);
    }

	public void supprimerDepartement1(Long id) {
		// TODO Auto-generated method stub
		
	}

	public Optional<Departement> getDepartementById1(Long id) {
		// TODO Auto-generated method stub
		return null;
	}



	public List<Departement> getAllDepartements1() {
		// TODO Auto-generated method stub
		return null;
	}
}
