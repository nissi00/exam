package service;

import java.util.List;

import univ.fac.model.Employe;

public interface EmployeRepository {



	List<Employe> findByDepartementId(Long departementId);

	Employe save(Employe employe);

}
