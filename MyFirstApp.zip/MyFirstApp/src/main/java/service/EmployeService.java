package service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import univ.fac.model.Employe;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;

@Service
public class EmployeService {

    @Autowired
    private EmployeRepository employeRepository;

    private final String uploadDir = "C:/uploads/employes/";

    public univ.fac.model.Employe ajouterEmploye(Employe employe, MultipartFile photo) throws IOException {
        if (photo != null && !photo.isEmpty()) {
            String filePath = uploadDir + photo.getOriginalFilename();
            File directory = new File(uploadDir);
            if (!directory.exists()) {
                directory.mkdirs(); // Crée le dossier s'il n'existe pas
            }
            photo.transferTo(Paths.get(filePath)); // Sauvegarde le fichier
            employe.setPhotoPath(filePath); // Enregistre le chemin en base
        }
        return employeRepository.save(employe);
    }

	public List<Employe> getEmployesByDepartement(Long id) {
		// TODO Auto-generated method stub
		return null;
	}
}
